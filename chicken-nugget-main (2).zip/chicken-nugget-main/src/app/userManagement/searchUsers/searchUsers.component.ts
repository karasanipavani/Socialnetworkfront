import { Component, OnInit } from '@angular/core';
import { UserManagementService } from '../userManagement.service';
import { Router } from '@angular/router';
import { UserAuthService } from '../../userAuth/userAuth.service';

@Component({
    selector: 'app-searchUsers',
    templateUrl: './searchUsers.component.html',
    styleUrls: ['./searchUsers.component.css']
})

export class SearchUsersComponent implements OnInit {

    searchText: any;
    foundUsers: any = [];

    constructor(private userManagementService: UserManagementService, private userAuthService: UserAuthService, private router: Router) {
    }

    ngOnInit() {
    }

    searchUsers() {
        if(this.searchText == '') {
            this.foundUsers = [];
            return
        } 
        this.userManagementService.searchUsers(this.userAuthService.getAuthToken(), this.searchText).subscribe(
            (response) => {
                this.foundUsers = response.users;
            },
            (error) => {
                console.error('Authentication error:', error);
                this.foundUsers = []
            }
        );
    }

}