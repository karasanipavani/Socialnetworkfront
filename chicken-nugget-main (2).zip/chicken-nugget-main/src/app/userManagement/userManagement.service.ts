import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../environment';

@Injectable({
    providedIn: 'root'
})
export class UserManagementService {

    authToken: any;
    user: any;

    constructor(private http: HttpClient) {
    }

    searchUsers(authToken: string, searchText: string) {
        const params = new HttpParams()
            .set('authToken', authToken)
            .set('searchText', searchText);
        return this.http.get<any>(environment.domain + '/searchUser', { params });
    }

}
