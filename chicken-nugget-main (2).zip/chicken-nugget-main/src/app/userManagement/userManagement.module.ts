// userAuth.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserManagementComponent } from './userManagement.component';
import { RouterModule, Routes } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
import { SearchUsersComponent } from './searchUsers/searchUsers.component';
import { UpdateProfileComponent } from './updateProfile/updateProfile.component';
import { FollowersComponent } from './followers/followers.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms'; // Import ReactiveFormsModule

const userManagementRoutes: Routes = [
    { path: 'user/:username', component: ProfileComponent },
    { path: 'user/:username/followers', component: FollowersComponent },
    { path: 'user/:username/following', component: FollowersComponent },
    { path: 'profile', component: ProfileComponent },
    { path: 'searchUser', component: SearchUsersComponent},
    { path: 'updateProfile', component: UpdateProfileComponent}
];

@NgModule({
    declarations: [
        UserManagementComponent,
        ProfileComponent,
        SearchUsersComponent,
        UpdateProfileComponent,
        FollowersComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(userManagementRoutes)
    ],
    exports: [
        UserManagementComponent,
        ProfileComponent,
        SearchUsersComponent,
        UpdateProfileComponent,
        FollowersComponent
    ]
})
export class UserManagementModule {}