import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-updateProfile',
    templateUrl: './updateProfile.component.html',
    styleUrls: ['./updateProfile.component.css']
})

export class UpdateProfileComponent implements OnInit {
    ngOnInit() {
    }

}