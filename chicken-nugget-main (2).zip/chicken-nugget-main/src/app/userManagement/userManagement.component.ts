import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-userManagement',
    templateUrl: './userManagement.component.html',
    styleUrls: ['./userManagement.component.css']
})

export class UserManagementComponent implements OnInit {
    ngOnInit() {
    }

}