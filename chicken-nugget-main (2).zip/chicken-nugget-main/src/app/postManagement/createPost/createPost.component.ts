import { Component, OnInit } from '@angular/core';
import { PostManagementService } from '../postManagement.service';

@Component({
    selector: 'app-createPost',
    templateUrl: './createPost.component.html',
    styleUrls: ['./createPost.component.css']
})

export class CreatePostComponent implements OnInit {
    
    fileToUpload: File | null = null;
    fileName: any;
    postError: any;

    constructor(private postManagementService: PostManagementService) { }
    
    handleFileInput(event: any) {
        let file: File = event.target.files[0]
        if(file && (file.type == 'image/jpeg' || file.type == 'image/jpg' || file.type == 'image/png')){
            this.fileToUpload = file;
            this.fileName = file.name;
        } else {
            this.postError = "File format not supported";
            this.fileName = null;
            this.fileToUpload = null;
        }
    }
    
    uploadFile() {

    }

    ngOnInit() {
    }

}