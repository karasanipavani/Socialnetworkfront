// userAuth.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostManagementComponent } from './postManagement.component';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PostViewComponent } from './postView/postView.component';
import { CreatePostComponent } from './createPost/createPost.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms'; // Import ReactiveFormsModule

const postManagementRoutes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'post/:id', component: PostViewComponent},
    { path: 'createPost', component: CreatePostComponent}
];

@NgModule({
    declarations: [
        PostManagementComponent,
        HomeComponent,
        PostViewComponent,
        CreatePostComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(postManagementRoutes)
    ],
    exports: [
        PostManagementComponent,
        HomeComponent,
        PostViewComponent,
        CreatePostComponent
    ]
})
export class PostManagementModule {}