import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../environment';

@Injectable({
    providedIn: 'root'
})
export class PostManagementService {

    authToken: any;
    user: any;

    constructor(private http: HttpClient) {
    }

    getHomePosts(authToken: string) {
        const params = new HttpParams()
            .set('authToken', authToken);
        return this.http.get<any>(environment.domain + '/getPosts', { params });
    }

    likePost(authToken: string, postId: string) {
        const params = new HttpParams()
            .set('authToken', authToken)
            .set('postId', postId);
        return this.http.get<any>(environment.domain + '/likePost', { params });
    }

    unLikePost(authToken: string, postId: string) {
        const params = new HttpParams()
            .set('authToken', authToken)
            .set('postId', postId);
        return this.http.get<any>(environment.domain + '/unLikePost', { params });
    }

    commentOnPost(authToken: string, postId: string, comment: string) {
        const params = new HttpParams()
            .set('authToken', authToken)
            .set('postId', postId)
            .set('comment', comment);
        return this.http.get<any>(environment.domain + '/commentOnPost', { params });
    }

    deleteComment(authToken: string, commentId: string) {
        const params = new HttpParams()
            .set('authToken', authToken)
            .set('commentId', commentId);
        return this.http.get<any>(environment.domain + '/deleteComment', { params });
    }

    createPost(authToken: string, content: string, file: File) {
        const formData: FormData = new FormData();
        formData.append('authToken', authToken);
        formData.append('content', content);
        formData.append('file', file);
        return this.http.post<any>(environment.domain + '/createPost', formData);
    }

    deletePost(authToken: string, postId: string) {
        const params = new HttpParams()
            .set('authToken', authToken)
            .set('postId', postId);
        return this.http.get<any>(environment.domain + '/deletePost', { params });
    }

    viewPost(authToken: string, postId: string) {
        const params = new HttpParams()
            .set('authToken', authToken)
            .set('postId', postId);
        return this.http.get<any>(environment.domain + '/viewPost', { params });
    }

}
