import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-postManagement',
    templateUrl: './postManagement.component.html',
    styleUrls: ['./postManagement.component.css']
})

export class PostManagementComponent implements OnInit {
    ngOnInit() {
    }

}