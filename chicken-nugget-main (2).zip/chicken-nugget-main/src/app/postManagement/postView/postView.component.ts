import { Component, OnInit } from '@angular/core';
import { PostManagementService } from '../postManagement.service';
import { UserAuthService } from '../../userAuth/userAuth.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-postView',
    templateUrl: './postView.component.html',
    styleUrls: ['./postView.component.css']
})

export class PostViewComponent implements OnInit {

    showDeleteCommentDropDown = false;
    showPostDeleteDropDown = false;
    postId: any;
    post: any;
    isUserPost: boolean = false;
    user: any;
    comment: any;
    isPostLoaded: boolean = false;

    constructor(private postManagementService: PostManagementService, private userAuthService: UserAuthService, private route: ActivatedRoute, private router: Router) {
        this.route.paramMap.subscribe(params => {
            this.postId = params.get('id');
        }); 
        postManagementService.viewPost(userAuthService.getAuthToken(), this.postId).subscribe(
            (response) => {
                this.post = response.post;
                this.user = userAuthService.getUser();
                console.log(this.post)
                this.isUserPost = this.post.user.userName === this.user.userName;
                this.isPostLoaded = true;
            },
            (error) => {
                console.error('Authentication error:', error);
                this.userAuthService.clearAuthToken();
                this.router.navigate(['/auth/login']);
            }
        );
    }

    ngOnInit() {
    }

    getNormalDate(dateString: any) {
        const date = new Date(dateString);
        const formattedDate = date.toLocaleDateString();
        return formattedDate;
    }

    deletePost(postId: string) {

    }

    likePost() {
        this.postManagementService.likePost(this.userAuthService.getAuthToken(), this.post.id).subscribe(
            (response) => {
                this.post.isLikedByUser = true;
                this.post.likeCount += 1;
            },
            (error) => {
                console.error('Authentication error:', error);
            }
        );
    }

    unLikePost() {
        this.postManagementService.unLikePost(this.userAuthService.getAuthToken(), this.post.id).subscribe(
            (response) => {
                this.post.isLikedByUser = false;
                this.post.likeCount -= 1;
            },
            (error) => {
                console.error('Authentication error:', error);
            }
        );
    }

    commentOnPost() {
        this.postManagementService.commentOnPost(this.userAuthService.getAuthToken(), this.post.id, this.comment).subscribe(
            (response) => {
                this.post.comments.push(response.comment);
                this.post.commentCount += 1;
            },
            (error) => {
                console.error('Authentication error:', error);
            }
        );
    }

}