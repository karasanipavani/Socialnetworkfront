import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './userAuth/authGuard.service';

const routes: Routes = [
    // { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'auth', loadChildren: () => import('./userAuth/userAuth.module').then(m => m.UserAuthModule) },
    { path: '', loadChildren: () => import('./postManagement/postManagement.module').then(m => m.PostManagementModule), canActivate: [AuthGuard] },
    { path: '', loadChildren: () => import('./userManagement/userManagement.module').then(m => m.UserManagementModule), canActivate: [AuthGuard] }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
