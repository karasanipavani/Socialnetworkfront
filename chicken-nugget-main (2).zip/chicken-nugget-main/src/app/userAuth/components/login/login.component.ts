import { Component, OnInit } from '@angular/core';
import { UserAuthService } from '../../userAuth.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css'],
})

export class LoginComponent implements OnInit {

    userName: string = "";
    password: string = "";
    loginError: String = "";

    constructor(private userAuthService: UserAuthService, private router: Router) { }

    ngOnInit() {
        if(this.userAuthService.isLoggedIn()) {
            this.router.navigate(['']);
        }
    }

    login() {
        this.userAuthService.login(this.userName, this.password).subscribe(
            (response) => {
                const authToken = response.authToken;
                const user = response.user;
                this.userAuthService.setAuthToken(authToken);
                this.userAuthService.setUser(user);
                this.router.navigate(['']);
            },
            (error) => {
                this.loginError = error.error;
                console.log(this.loginError)
                console.error('Authentication error:', error);
            }
        );
    }

}