import { Component, OnInit } from '@angular/core';
import { UserAuthService } from '../../userAuth.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.css']
})

export class SignupComponent implements OnInit {

    userName: string = "";
    password: string = "";
    confirmPassword: string = "";
    signUpError: String = "";

    constructor(private userAuthService: UserAuthService, private router: Router) { }

    ngOnInit() {
        if(this.userAuthService.isLoggedIn()) {
            this.router.navigate(['']);
        }
    }

    signUp() {
        if(this.password !== this.confirmPassword) {
            this.signUpError = "Passwords do not match.";
            return;
        }
        if(this.userName.includes(" ")) {
            this.signUpError = "Username cannot contain empty spaces.";
            return;
        }
        this.userAuthService.signUp(this.userName, this.password).subscribe(
            (response) => {
                const user = response.user;
                this.userAuthService.setUser(user);
                this.router.navigate(['/auth/login']);
            },
            (error) => {
                this.signUpError = error.error;
                console.log(this.signUpError)
                console.error('Authentication error:', error);
            }
        );
    }

}
