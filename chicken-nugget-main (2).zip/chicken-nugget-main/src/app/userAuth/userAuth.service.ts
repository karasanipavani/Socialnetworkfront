import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { environment } from '../../environment';

@Injectable({
    providedIn: 'root'
})
export class UserAuthService {

    authToken: any;
    user: any;

    constructor(private cookieService: CookieService, private http: HttpClient) { 
    }

    getAuthToken(): string {
        return this.authToken;
    }

    setAuthToken(authToken: string) {
        console.log(authToken, "set")
        this.authToken = authToken
        this.cookieService.set('authToken', authToken);
    }

    setAuthTokenFromCookie() {
        let authToken = this.cookieService.get('authToken')
        this.validateAuthToken(authToken).subscribe(
            (response) => {
                this.authToken = authToken;
                this.user = response.user;
            },
            (error) => {
                console.error('Authentication error:', error);
                this.clearAuthToken();
            }
        );
    }

    validateAuthToken(authToken: any) {
        const params = new HttpParams()
            .set('authToken', authToken);
        return this.http.get<any>(environment.domain + '/validateToken', { params });
    }

    clearAuthToken() {
        this.authToken = null;
        this.cookieService.delete('authToken');
    }

    isLoggedIn(): boolean {
        return !!this.authToken;
    }

    setUser(user: any) {
        this.user = user;
    }

    login(username: string, password: string) {
        const params = new HttpParams()
            .set('userName', username)
            .set('password', password);
        return this.http.get<any>(environment.domain + '/login', { params });
    }

    signUp(username: string, password: string) {
        const params = new HttpParams()
            .set('userName', username)
            .set('password', password);
        return this.http.get<any>(environment.domain + '/signUp', { params });
    }

    getUser() {
        return this.user;
    }

}
